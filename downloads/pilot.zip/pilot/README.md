# ✈ Pilot — AI Operator Setup Wizard

Pilot is an interactive local setup wizard that guides you through building your full AI Operator + AWS stack — step by step, no assumptions, no jargon.

## What it sets up

- **AWS credentials** — written to `~/.aws/`
- **Amplify** — web hosting with auto-deploy
- **SES** — outbound email from your domain
- **ImprovMX** — inbound email forwarding
- **AI Operator config** — fully configured with your API keys and model preferences

## Run it

```bash
pip install flask
python pilot.py
```

Then open **http://localhost:7700** in your browser.

Pilot will walk you through everything. It won't assume anything about your setup.

## What you'll need

- An **AWS account** with an Access Key ID + Secret Access Key
- Your **domain name** (registered anywhere — Route53, GoDaddy, Namecheap, etc.)
- **API keys** for the AI providers you want to use (Anthropic, OpenAI, xAI, etc.)
- Your AI Operator account (visit ai-operator.biz to get started)
- Optionally: an **ImprovMX API key** for email forwarding

## Architecture

```
pilot.py           → Flask server + conversation engine
static/index.html  → Chat UI (single file, no build step)
requirements.txt   → Just flask
```

## Ports

Default: `7700`. Override with `PORT=8080 python pilot.py`.

---

Made with care by [Secure by Dezign](https://securebydezign.com)
