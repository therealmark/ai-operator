#!/usr/bin/env python3
"""
Pilot — Your runway to AI Operator.

Guides customers through collecting credentials, writing openclaw.json,
and configuring their AWS environment — entirely locally.

Usage:
  pip install flask
  python pilot.py
  → open http://localhost:7700
"""

import json, os, re, subprocess, sys, uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from flask import Flask, Response, jsonify, request, send_from_directory

# ─── App ──────────────────────────────────────────────────────────────────────

STATIC = Path(__file__).parent / "static"
app = Flask(__name__, static_folder=str(STATIC))
app.secret_key = os.urandom(32)

SESSIONS: Dict[str, dict] = {}

# ─── Booking link (update if Calendly or other scheduler is set up) ───────────
BOOKING_URL = "https://book.stripe.com/cNi3cucnggacgDu56pb7y0g"

# ─── Stage bar ────────────────────────────────────────────────────────────────
STAGES = ["Welcome", "Credentials", "Domain", "Email", "Review", "Done"]

# ─── Step definition ──────────────────────────────────────────────────────────

@dataclass
class Step:
    id: str
    stage: str
    prompt: Union[str, Callable]
    key: Optional[str] = None
    input_type: str = "text"
    choices: Optional[List[str]] = None
    choice_labels: Optional[List[str]] = None
    validate: Optional[Callable] = None
    transform: Optional[Callable] = None
    skip_if: Optional[Callable] = None
    ack: Optional[Union[str, Callable]] = None
    placeholder: str = ""
    triggers_execute: bool = False


# ─── Validators ───────────────────────────────────────────────────────────────

def validate_nonempty(v, _data):
    return (True, None) if str(v).strip() else (False, "I need a value here — go ahead and fill it in.")

def validate_domain(v, _data):
    if re.match(r'^[a-z0-9][a-z0-9\-\.]+\.[a-z]{2,}$', v.strip().lower()):
        return True, None
    return False, "Doesn't look like a valid domain — something like `mysite.com` or `yourbrand.io`"

def validate_aws_key(v, _data):
    if re.match(r'^AKIA[0-9A-Z]{16}$', v.strip()):
        return True, None
    return False, "AWS Access Key IDs start with `AKIA` and are 20 characters — double-check that one."

def validate_aws_secret(v, _data):
    if len(v.strip()) == 40:
        return True, None
    return False, "AWS Secret Access Keys are exactly 40 characters — that one looks off."

def validate_email(v, _data):
    if re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', v.strip()):
        return True, None
    return False, "That doesn't look like a valid email address."


# ─── Constants ────────────────────────────────────────────────────────────────

REGION_MAP = {
    "1": "us-east-1",
    "2": "us-west-2",
    "3": "eu-west-1",
    "4": "ap-southeast-1",
    "5": "ap-northeast-1",
}

AI_PROVIDERS = {
    "1": ("anthropic", "Anthropic (Claude)",  "api_key_anthropic"),
    "2": ("openai",    "OpenAI (GPT)",        "api_key_openai"),
    "3": ("xai",       "xAI (Grok)",          "api_key_xai"),
    "4": ("google",    "Google (Gemini)",      "api_key_google"),
    "5": ("mistral",   "Mistral",              "api_key_mistral"),
}

PRIMARY_MODEL_MAP = {
    "1": "anthropic/claude-sonnet-4-5",
    "2": "openai/gpt-4o",
    "3": "xai/grok-4",
    "4": "google/gemini-2.0-flash",
    "5": "mistral/mistral-large-latest",
}

# Full provider config for writing valid openclaw.json.
# baseUrl and models[] are required by OpenClaw's schema.
PROVIDER_REGISTRY = {
    "anthropic": {
        "name":         "Anthropic (Claude)",
        "baseUrl":      "https://api.anthropic.com",
        "api":          "anthropic-messages",
        "primaryModel": "anthropic/claude-sonnet-4-5",
        "models": [
            {"id": "claude-opus-4-5",   "name": "Claude Opus 4",    "input": ["text", "image"]},
            {"id": "claude-sonnet-4-5", "name": "Claude Sonnet 4",  "input": ["text", "image"]},
            {"id": "claude-haiku-3-5",  "name": "Claude Haiku 3.5", "input": ["text", "image"]},
        ],
    },
    "openai": {
        "name":         "OpenAI (GPT)",
        "baseUrl":      "https://api.openai.com/v1",
        "api":          "openai-completions",
        "primaryModel": "openai/gpt-4o",
        "models": [
            {"id": "gpt-4o",       "name": "GPT-4o",       "input": ["text", "image"]},
            {"id": "gpt-4o-mini",  "name": "GPT-4o Mini",  "input": ["text", "image"]},
        ],
    },
    "xai": {
        "name":         "xAI (Grok)",
        "baseUrl":      "https://api.x.ai/v1",
        "api":          "openai-completions",
        "primaryModel": "xai/grok-4",
        "models": [
            {"id": "grok-4",       "name": "Grok 4",       "input": ["text", "image"]},
            {"id": "grok-3-fast",  "name": "Grok 3 Fast",  "input": ["text"]},
        ],
    },
    "google": {
        "name":         "Google (Gemini)",
        "baseUrl":      "https://generativelanguage.googleapis.com/v1beta/openai/",
        "api":          "openai-completions",
        "primaryModel": "google/gemini-2.0-flash",
        "models": [
            {"id": "gemini-2.0-flash",  "name": "Gemini 2.0 Flash",  "input": ["text", "image"]},
            {"id": "gemini-1.5-pro",    "name": "Gemini 1.5 Pro",    "input": ["text", "image"]},
        ],
    },
    "mistral": {
        "name":         "Mistral",
        "baseUrl":      "https://api.mistral.ai/v1",
        "api":          "openai-completions",
        "primaryModel": "mistral/mistral-large-latest",
        "models": [
            {"id": "mistral-large-latest", "name": "Mistral Large", "input": ["text"]},
            {"id": "mistral-small-latest", "name": "Mistral Small", "input": ["text"]},
        ],
    },
}


def detect_provider(key: str):
    """Detect AI provider from API key prefix.
    Returns (provider_id, provider_name, key_field, default_model) or (None, ...) for empty."""
    k = (key or "").strip()
    if not k:
        return (None, "None", None, None)
    if k.startswith("sk-ant-"):
        return ("anthropic", "Anthropic (Claude)", "api_key_anthropic", "anthropic/claude-sonnet-4-5")
    if k.startswith("sk-"):          # sk-proj-... or legacy sk-...
        return ("openai", "OpenAI (GPT)", "api_key_openai", "openai/gpt-4o")
    if k.startswith("xai-"):
        return ("xai", "xAI (Grok)", "api_key_xai", "xai/grok-4")
    if k.startswith("AIza"):
        return ("google", "Google (Gemini)", "api_key_google", "google/gemini-2.0-flash")
    # No well-known prefix — fall back to Mistral (random hex keys)
    return ("mistral", "Mistral", "api_key_mistral", "mistral/mistral-large-latest")


# ─── Steps ────────────────────────────────────────────────────────────────────

def build_steps():
    return [

        # ── WELCOME ────────────────────────────────────────────────────────────
        Step(
            id="name",
            stage="Welcome",
            prompt=(
                "Hey! I'm **Pilot** — I'll get your AI Operator environment ready in a few minutes.\n\n"
                "I'll collect your credentials, write your configuration, and set up your AWS "
                "environment. Everything stays on this machine — nothing is sent anywhere else.\n\n"
                "**What should I call you?**"
            ),
            key="name",
            input_type="text",
            placeholder="Your name",
            validate=validate_nonempty,
        ),

        # ── CREDENTIALS (all upfront) ──────────────────────────────────────────

        # (OpenClaw key removed — not a real credential)

        # AWS region
        Step(
            id="aws_region",
            stage="Credentials",
            prompt=lambda d: (
                f"Nice to meet you, **{d.get('name','there')}**! 👋\n\n"
                "Fill in your credentials in the panel on the right — I'll skip anything you've already entered there.\n\n"
                "**AWS region** — where should your resources live?\n\n"
                "**1** — us-east-1 (N. Virginia) — broadest service coverage ✓  \n"
                "**2** — us-west-2 (Oregon)  \n"
                "**3** — eu-west-1 (Ireland)  \n"
                "**4** — ap-southeast-1 (Singapore)  \n"
                "**5** — ap-northeast-1 (Tokyo)"
            ),
            key="aws_region_choice",
            input_type="choice",
            choices=["1", "2", "3", "4", "5"],
            choice_labels=list(REGION_MAP.values()),
            transform=lambda v: REGION_MAP.get(v, "us-east-1"),
        ),

        # AWS access key
        Step(
            id="aws_key_id",
            stage="Credentials",
            prompt=(
                "**AWS Access Key ID:**  \n"
                "→ *Create one at [console.aws.amazon.com/iam](https://console.aws.amazon.com/iam/) — needs AdministratorAccess for setup*"
            ),
            key="aws_access_key_id",
            input_type="password",
            placeholder="AKIAIOSFODNN7EXAMPLE",
            validate=validate_aws_key,
            transform=lambda v: v.strip(),
        ),

        # AWS secret
        Step(
            id="aws_secret",
            stage="Credentials",
            prompt="**AWS Secret Access Key:**",
            key="aws_secret_access_key",
            input_type="password",
            placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            validate=validate_aws_secret,
            transform=lambda v: v.strip(),
        ),

        # AI key — single input, provider is auto-detected from the key prefix
        Step(
            id="ai_key",
            stage="Credentials",
            prompt=(
                "**AI API key** — paste your key and I'll figure out the provider automatically:\n\n"
                "→ **Anthropic (Claude):** `sk-ant-...` — [console.anthropic.com](https://console.anthropic.com/)  \n"
                "→ **OpenAI (GPT):** `sk-proj-...` — [platform.openai.com/api-keys](https://platform.openai.com/api-keys)  \n"
                "→ **xAI (Grok):** `xai-...` — [console.x.ai](https://console.x.ai/)  \n"
                "→ **Google (Gemini):** `AIza...` — [aistudio.google.com/apikey](https://aistudio.google.com/apikey)  \n"
                "→ **Mistral:** paste your key — [console.mistral.ai/api-keys](https://console.mistral.ai/api-keys/)"
            ),
            key="ai_key_raw",
            input_type="password",
            placeholder="sk-ant-...  or  sk-proj-...  or  xai-...  or  AIza...",
            validate=lambda v, d: (True, None) if v.strip() else (False, "An API key is required."),
            transform=lambda v: v.strip(),
        ),

        # GitHub token
        Step(
            id="github_token",
            stage="Credentials",
            prompt=(
                "**GitHub Personal Access Token:**  \n"
                "→ *[github.com/settings/tokens](https://github.com/settings/tokens) — needs `repo` scope*  \n"
                "→ *Leave blank to skip (you can add it to your config later)*"
            ),
            key="github_token",
            input_type="password",
            placeholder="ghp_...  or  leave blank",
            validate=validate_nonempty,
            transform=lambda v: v.strip() if v.strip().lower() not in ("skip", "") else "",
        ),

        # ImprovMX (optional)
        Step(
            id="improvmx_key",
            stage="Credentials",
            prompt=(
                "**ImprovMX API key** *(optional — for email forwarding)*:  \n"
                "→ *[app.improvmx.com/api](https://app.improvmx.com/api)*  \n"
                "→ *Type `skip` to leave email forwarding for later*"
            ),
            key="improvmx_api_key",
            input_type="password",
            placeholder="your-key  or  skip",
            validate=validate_nonempty,
            transform=lambda v: None if v.strip().lower() in ("skip", "") else v.strip(),
        ),

        # ── DOMAIN ─────────────────────────────────────────────────────────────
        Step(
            id="domain",
            stage="Domain",
            prompt=(
                "Great — all credentials collected. Now a couple of quick config questions.\n\n"
                "**What domain name will your AI Operator site live on?**  \n"
                "→ *Examples: `mysite.com`, `yourbrand.io`*"
            ),
            key="domain",
            input_type="text",
            placeholder="yourdomain.com",
            validate=validate_domain,
            transform=lambda v: v.strip().lower(),
        ),
        Step(
            id="github_repo",
            stage="Domain",
            prompt=(
                "**GitHub repo** for your AI Operator site:  \n"
                "→ *Format: `username/repo-name`*  \n"
                "→ *Leave blank to skip for now*"
            ),
            key="github_repo",
            input_type="text",
            placeholder="username/my-repo  or  leave blank",
            validate=validate_nonempty,
            transform=lambda v: v.strip() if v.strip() not in ("skip", "") else "",
        ),

        # ── EMAIL ──────────────────────────────────────────────────────────────
        Step(
            id="email_from",
            stage="Email",
            prompt=lambda d: (
                f"**Email address to send from:**  \n"
                f"→ *This will be verified in AWS SES — e.g. `hello@{d.get('domain','yourdomain.com')}`*"
            ),
            key="email_from",
            input_type="text",
            placeholder=lambda d: f"hello@{d.get('domain','yourdomain.com')}",
            validate=validate_email,
            transform=lambda v: v.strip().lower(),
        ),
        Step(
            id="improvmx_forward",
            stage="Email",
            prompt=lambda d: (
                f"**Forward emails to:**  \n"
                f"→ *Where emails sent to `{d.get('email_from','...')}` should land*"
            ),
            key="improvmx_forward_to",
            input_type="text",
            placeholder="you@gmail.com",
            validate=validate_email,
            transform=lambda v: v.strip().lower(),
            skip_if=lambda d: not d.get("improvmx_api_key"),
        ),

        # ── REVIEW → EXECUTE ───────────────────────────────────────────────────
        Step(
            id="review",
            stage="Review",
            prompt=lambda d: build_review_prompt(d),
            key=None,
            input_type="confirm",
            choice_labels=["Set it up 🚀", "Wait — let me change something"],
            triggers_execute=True,
        ),
    ]


def build_review_prompt(d: dict) -> str:
    provider_id, provider_name, key_field, default_model = detect_provider(d.get("ai_key_raw", ""))
    key_display = "✓ set" if d.get("ai_key_raw") else "⚠️ missing"

    return (
        "Here's everything I'm about to configure. Take a look.\n\n"

        f"☁️  **AWS Region:** `{d.get('aws_region_choice','—')}`  \n"
        f"🔐 **AWS Key ID:** `{d.get('aws_access_key_id','—')[:8]}...`  \n"
        f"🤖 **AI Provider:** {provider_name} — key {key_display}  \n"
        f"⭐ **Primary model:** `{default_model or '—'}`  \n"
        f"🌐 **Domain:** `{d.get('domain','—')}`  \n"
        f"📂 **GitHub repo:** `{d.get('github_repo','—') or '(none)'}`  \n"
        f"✉️  **Send from:** `{d.get('email_from','—')}`  \n"
        + (f"📬 **Forward to:** `{d.get('improvmx_forward_to','—')}`  \n" if d.get("improvmx_api_key") else "") +
        "\n**What I'll do:**  \n"
        "→ Write `~/.aws/credentials` and `~/.aws/config`  \n"
        "→ Verify AWS credentials  \n"
        "→ Verify your SES email identity  \n"
        + ("→ Configure ImprovMX email forwarding  \n" if d.get("improvmx_api_key") else "") +
        "→ Write AI Operator config  \n\n"
        "Ready?"
    )


# ─── Session helpers ──────────────────────────────────────────────────────────

def get_state(sid: str) -> dict:
    if sid not in SESSIONS:
        SESSIONS[sid] = {
            "step_index": 0,
            "data": {},
            "phase": "chat",
            "exec_log": [],
        }
    return SESSIONS[sid]


def resolve_prompt(step: Step, data: dict) -> str:
    if callable(step.prompt):
        return step.prompt(data)
    return step.prompt


def _step_prefilled(step: Step, data: dict) -> bool:
    """Return True if the step's key already has a value in data (from the credentials panel)."""
    if not step.key:
        return False
    val = data.get(step.key)
    if val is None:
        return False
    if isinstance(val, str):
        return val.strip() != ""
    if isinstance(val, list):
        return len(val) > 0
    return bool(val)


def current_step(state: dict, steps: list) -> Optional[Step]:
    """Return the current step, advancing past any that are already prefilled."""
    while state["step_index"] < len(steps):
        step = steps[state["step_index"]]
        if (step.skip_if and step.skip_if(state["data"])) or _step_prefilled(step, state["data"]):
            state["step_index"] += 1
        else:
            return step
    return None


def advance(state: dict, steps: list) -> Optional[Step]:
    state["step_index"] += 1
    while state["step_index"] < len(steps):
        step = steps[state["step_index"]]
        if (step.skip_if and step.skip_if(state["data"])) or _step_prefilled(step, state["data"]):
            state["step_index"] += 1
        else:
            return step
    return None


def _input_meta(step: Step, data: dict) -> dict:
    placeholder = step.placeholder
    if callable(placeholder):
        placeholder = placeholder(data)
    return {
        "input_type":   step.input_type,
        "choices":      step.choices,
        "choice_labels":step.choice_labels,
        "placeholder":  placeholder,
        "stage":        step.stage,
        "stage_index":  STAGES.index(step.stage) if step.stage in STAGES else 0,
        "total_stages": len(STAGES),
    }


def _msg(text: str, meta: dict, done: bool = False, trigger_execute: bool = False) -> dict:
    return {"text": text, "meta": meta, "done": done, "trigger_execute": trigger_execute}


def process_message(state: dict, steps: list, raw: str) -> dict:
    step  = current_step(state, steps)
    if not step:
        return _msg("All done — refresh to start a new session.", {})

    value = raw.strip()

    # Multiselect
    if step.input_type == "multiselect":
        value = [x.strip() for x in re.split(r"[,\s]+", value) if x.strip()]

    # Confirm
    if step.input_type == "confirm":
        lower = value.lower() if isinstance(value, str) else ""
        value = lower in ("yes", "y", "1", "go", "launch", "set it up", "🚀")

    # Validate
    if step.validate:
        ok, err = step.validate(value, state["data"])
        if not ok:
            return _msg(f"⚠️ {err}", _input_meta(step, state["data"]))

    # Transform
    if step.transform:
        value = step.transform(value)

    # Store
    if step.key:
        state["data"][step.key] = value

    # Confirm rejected → restart
    if step.input_type == "confirm" and not value and step.triggers_execute:
        state["step_index"] = 0
        ns = steps[0]
        return _msg("No problem — let's start over.\n\n" + resolve_prompt(ns, state["data"]), _input_meta(ns, state["data"]))

    # Confirm accepted → execute
    if step.input_type == "confirm" and value and step.triggers_execute:
        state["phase"] = "executing"
        return _msg(
            "Perfect. Setting everything up now… 🚀",
            {"input_type": "none"},
            trigger_execute=True,
        )

    # Advance
    next_step = advance(state, steps)
    if not next_step:
        return _msg("All done!", {"input_type": "none"}, done=True)

    ack  = _build_ack(step, value, state["data"])
    body = resolve_prompt(next_step, state["data"])
    reply = f"{ack}\n\n{body}" if ack else body
    return _msg(reply, _input_meta(next_step, state["data"]))


def _build_ack(step: Step, value, data: dict) -> str:
    if step.ack:
        return step.ack(value, data) if callable(step.ack) else step.ack
    if step.id == "name":
        return ""  # ack will be in the next prompt
    if step.input_type == "password":
        return "✓ Saved."
    if step.input_type in ("choice", "multiselect"):
        return "Got it."
    if step.id == "domain":
        return f"Domain set to `{value}`."
    return ""


# ─── Execute phase ─────────────────────────────────────────────────────────────

import time, urllib.request, base64


def run_execute(state: dict):
    """Generator — yields SSE data lines while configuring the environment."""
    d   = state["data"]
    log = state["exec_log"]

    def emit(line: str, status: str = "info"):
        entry = {"line": line, "status": status}
        log.append(entry)
        yield f"data: {json.dumps({'type': 'exec_line', 'line': line, 'status': status})}\n\n"

    def run(cmd: list, env=None, timeout=60):
        full_env = {**os.environ, **(env or {})}
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, env=full_env, timeout=timeout)
            return r.returncode == 0, (r.stdout + r.stderr).strip()
        except Exception as e:
            return False, str(e)

    region  = d.get("aws_region_choice", "us-east-1")
    key_id  = d.get("aws_access_key_id", "")
    secret  = d.get("aws_secret_access_key", "")
    email   = d.get("email_from", "")
    domain  = d.get("domain", "")

    aws_env = {
        "AWS_ACCESS_KEY_ID":     key_id,
        "AWS_SECRET_ACCESS_KEY": secret,
        "AWS_DEFAULT_REGION":    region,
    }

    # ── 1. Verify AWS credentials ──────────────────────────────────────────
    yield from emit("🔑 Verifying AWS credentials…")
    ok, out = run(["aws", "sts", "get-caller-identity", "--output", "json"], aws_env)
    if ok:
        try:
            identity = json.loads(out)
            yield from emit(f"   ✓ Connected — account `{identity.get('Account','?')}`, user `{identity.get('Arn','').split('/')[-1]}`", "ok")
        except Exception:
            yield from emit("   ✓ Credentials accepted", "ok")
    else:
        yield from emit(f"   ✗ Credential check failed: {out[:200]}", "error")
        yield from emit("   → Continuing — you can fix credentials and re-run.", "warn")

    # ── 2. Write AWS config ────────────────────────────────────────────────
    yield from emit("\n💾 Writing AWS credentials…")
    aws_dir = Path.home() / ".aws"
    aws_dir.mkdir(exist_ok=True)
    try:
        (aws_dir / "credentials").write_text(
            f"[default]\naws_access_key_id = {key_id}\naws_secret_access_key = {secret}\n"
        )
        (aws_dir / "config").write_text(
            f"[default]\nregion = {region}\noutput = json\n"
        )
        yield from emit("   ✓ ~/.aws/credentials and ~/.aws/config written", "ok")
    except Exception as e:
        yield from emit(f"   ✗ Could not write AWS config: {e}", "error")

    # ── 3. SES email identity ──────────────────────────────────────────────
    if email:
        yield from emit(f"\n✉️  Verifying email identity `{email}` in SES…")
        ok, out = run([
            "aws", "sesv2", "create-email-identity",
            "--email-identity", email,
            "--region", region,
            "--output", "json",
        ], aws_env)
        if ok:
            yield from emit(f"   ✓ Verification email sent — check your inbox for `{email}`", "ok")
        elif "AlreadyExists" in out:
            yield from emit(f"   ✓ `{email}` already verified in SES", "ok")
        else:
            yield from emit(f"   ⚠️ SES: {out[:200]}", "warn")

        # SES sandbox check
        ok, out = run(["aws", "sesv2", "get-account", "--region", region, "--output", "json"], aws_env)
        if ok:
            try:
                sandbox = not json.loads(out).get("Details", {}).get("ProductionAccessEnabled", False)
                if sandbox:
                    yield from emit("   ℹ️  SES is in sandbox mode — request production access in the AWS console to send to any address.", "warn")
                else:
                    yield from emit("   ✓ SES production access is enabled", "ok")
            except Exception:
                pass

    # ── 4. ImprovMX ───────────────────────────────────────────────────────
    improvmx_key = d.get("improvmx_api_key")
    forward_to   = d.get("improvmx_forward_to")
    email_prefix = email.split('@')[0] if '@' in email else ""

    if improvmx_key and forward_to and domain:
        yield from emit(f"\n📬 Configuring ImprovMX for `{domain}`…")
        auth    = base64.b64encode(f"api:{improvmx_key}".encode()).decode()
        headers = {"Authorization": f"Basic {auth}", "Content-Type": "application/json"}

        try:
            req = urllib.request.Request(
                "https://api.improvmx.com/v3/domains/",
                data=json.dumps({"domain": domain}).encode(),
                headers=headers, method="POST",
            )
            with urllib.request.urlopen(req, timeout=15):
                yield from emit(f"   ✓ Domain `{domain}` added to ImprovMX", "ok")
        except Exception as e:
            err = str(e)
            if "already" in err.lower():
                yield from emit(f"   ✓ Domain already in ImprovMX", "ok")
            else:
                yield from emit(f"   ⚠️ ImprovMX domain: {err[:120]}", "warn")

        try:
            req = urllib.request.Request(
                f"https://api.improvmx.com/v3/domains/{domain}/aliases/",
                data=json.dumps({"alias": email_prefix, "forward": forward_to}).encode(),
                headers=headers, method="POST",
            )
            with urllib.request.urlopen(req, timeout=15):
                yield from emit(f"   ✓ Alias `{email_prefix}` → `{forward_to}`", "ok")
        except Exception as e:
            yield from emit(f"   ⚠️ ImprovMX alias: {str(e)[:120]}", "warn")

    # ── 5. Write openclaw.json ─────────────────────────────────────────────
    yield from emit("\n📝 Writing openclaw.json…")
    oc_dir = Path.home() / ".openclaw"
    oc_dir.mkdir(exist_ok=True)
    oc_path = oc_dir / "openclaw.json"

    # Detect provider and look up full registry config (baseUrl, api, models[])
    ai_key_raw = d.get("ai_key_raw", "")
    provider_id, provider_name, key_field, default_model = detect_provider(ai_key_raw)
    prov_cfg = PROVIDER_REGISTRY.get(provider_id, {}) if provider_id else {}

    if provider_id and ai_key_raw:
        yield from emit(f"   ✓ Detected provider: {provider_name}", "ok")
    elif not ai_key_raw:
        yield from emit("   ⚠️ No AI key provided — skipping AI provider config", "warn")

    # Build the providers block — schema requires baseUrl (string) and models (array)
    providers_block = {}
    if provider_id and ai_key_raw and prov_cfg:
        providers_block[provider_id] = {
            "baseUrl": prov_cfg["baseUrl"],
            "apiKey":  ai_key_raw,
            "api":     prov_cfg["api"],
            "models":  prov_cfg["models"],
        }

    # Build the auth.profiles block
    auth_profiles = {}
    if provider_id:
        auth_profiles[f"{provider_id}:default"] = {
            "provider": provider_id,
            "mode":     "api_key",
        }

    github_token = d.get("github_token", "")
    github_repo  = d.get("github_repo", "")
    primary_model = prov_cfg.get("primaryModel", "anthropic/claude-sonnet-4-5")

    # Write only schema-valid keys to openclaw.json
    oc_json = {}
    if auth_profiles:
        oc_json["auth"] = {"profiles": auth_profiles}
    if providers_block:
        oc_json["models"] = {"providers": providers_block}
    oc_json["agents"] = {
        "defaults": {
            "model": {"primary": primary_model},
            "workspace": str(Path.home() / ".openclaw" / "workspace"),
        }
    }
    if github_token:
        oc_json["env"] = {"vars": {"GITHUB_TOKEN": github_token}}

    try:
        # Merge with existing openclaw.json if present (preserve gateway, channels, etc.)
        existing = {}
        if oc_path.exists():
            try:
                existing = json.loads(oc_path.read_text())
            except Exception:
                pass

        def deep_merge(base: dict, overlay: dict) -> dict:
            result = dict(base)
            for k, v in overlay.items():
                if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                    result[k] = deep_merge(result[k], v)
                else:
                    result[k] = v
            return result

        merged = deep_merge(existing, oc_json)
        oc_path.write_text(json.dumps(merged, indent=2))
        yield from emit(f"   ✓ {oc_path} written", "ok")
    except Exception as e:
        yield from emit(f"   ✗ Could not write openclaw.json: {e}", "error")

    # Write pilot-specific config (aws, site, github, improvmx) to a separate file
    # so it doesn't pollute openclaw.json's strict schema
    pilot_cfg_path = oc_dir / "pilot-config.json"
    try:
        pilot_cfg = {
            "aws":     {"region": region, "sesFrom": email},
            "site":    {"domain": domain},
            "github":  {"token": github_token, "repo": github_repo} if github_token else {},
            "improvmx":{"apiKey": improvmx_key} if improvmx_key else {},
        }
        pilot_cfg_path.write_text(json.dumps(pilot_cfg, indent=2))
        yield from emit(f"   ✓ {pilot_cfg_path} written (AWS + site config)", "ok")
    except Exception as e:
        yield from emit(f"   ⚠️ Could not write pilot-config.json: {e}", "warn")

    # ── Done — emit a chat bubble with verification steps, then exec_done ──
    state["phase"] = "done"

    completion_text = (
        "✅ **Setup complete!**\n\n"
        f"AI Operator is configured for **{provider_name}** and ready to launch.\n\n"
        "**To verify your install, open a terminal and run:**\n\n"
        "`openclaw status`\n\n"
        "You should see your provider listed as connected. Then start your gateway:\n\n"
        "`openclaw gateway start`\n\n"
        "Your agent will be live at **http://localhost:18789** — open it in your browser to confirm.\n\n"
        "**Need a hand?** Book a session with your AI Operator Architect and we'll walk through "
        f"the rest of your launch together.\n\n"
        f"📅 [Schedule your session]({BOOKING_URL})"
    )
    yield f"data: {json.dumps({'type': 'bot_message', 'text': completion_text, 'meta': {'input_type': 'none'}})}\n\n"
    yield f"data: {json.dumps({'type': 'exec_done'})}\n\n"


# ─── Routes ───────────────────────────────────────────────────────────────────

STEPS_LIST = build_steps()


@app.route("/")
def index():
    return send_from_directory(str(STATIC), "index.html")


@app.route("/start", methods=["POST"])
def start():
    sid = str(uuid.uuid4())
    state = get_state(sid)
    first = STEPS_LIST[0]
    return jsonify({
        "session_id": sid,
        "text":       resolve_prompt(first, {}),
        "meta":       _input_meta(first, {}),
    })


@app.route("/credentials", methods=["POST"])
def credentials():
    """Accept key/value pairs from the credentials panel and merge into session data."""
    body = request.json or {}
    sid  = body.get("session_id", "")
    creds = body.get("credentials", {})

    if not sid or sid not in SESSIONS:
        return jsonify({"error": "Session not found"}), 400

    state = SESSIONS[sid]
    data  = state["data"]

    # Map panel field names → internal data keys
    FIELD_MAP = {
        "aws_access_key_id":    "aws_access_key_id",
        "aws_secret_access_key":"aws_secret_access_key",
        "aws_region":           "aws_region_choice",   # store the region string directly
        "api_key_anthropic":    "api_key_anthropic",
        "api_key_openai":       "api_key_openai",
        "api_key_xai":          "api_key_xai",
        "api_key_google":       "api_key_google",
        "api_key_mistral":      "api_key_mistral",
        "github_token":         "github_token",
        "improvmx_api_key":     "improvmx_api_key",
        "domain":               "domain",
        "github_repo":          "github_repo",
        "email_from":           "email_from",
        "improvmx_forward":     "improvmx_forward",
    }

    for panel_key, data_key in FIELD_MAP.items():
        val = creds.get(panel_key, "").strip()
        if val:
            data[data_key] = val

    # If any API key was filled in the sidebar, synthesize ai_key_raw so the
    # single-key chat step is skipped (first non-empty provider key wins).
    if not data.get("ai_key_raw"):
        for panel_key in ("api_key_anthropic", "api_key_openai", "api_key_xai",
                          "api_key_google", "api_key_mistral"):
            v = data.get(panel_key, "").strip()
            if v:
                data["ai_key_raw"] = v
                break

    # Reset step index so current_step() re-evaluates which steps are still needed
    state["step_index"] = 1   # keep past the name step

    # Find the next unfilled step to tell the front end what to ask next
    next_step = current_step(state, STEPS_LIST)
    if next_step:
        return jsonify({
            "ok": True,
            "next_prompt": resolve_prompt(next_step, data),
            "meta": _input_meta(next_step, data),
        })
    else:
        return jsonify({"ok": True, "next_prompt": None, "meta": {"input_type": "confirm"}})


@app.route("/chat", methods=["POST"])
def chat():
    body    = request.json or {}
    sid     = body.get("session_id", "")
    user_msg= body.get("message", "")

    if not sid or sid not in SESSIONS:
        return jsonify({"error": "Session not found — refresh to start over."}), 400

    state = get_state(sid)

    if state["phase"] == "executing":
        return Response(run_execute(state), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    result = process_message(state, STEPS_LIST, user_msg)

    if result.get("trigger_execute"):
        import itertools
        def stream():
            first = json.dumps({"type": "bot_message", "text": result["text"], "meta": result["meta"]})
            yield f"data: {first}\n\n"
            time.sleep(0.4)
            yield from run_execute(state)
        return Response(stream(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    return jsonify({"text": result["text"], "meta": result["meta"], "done": result.get("done", False)})


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 7700))
    print(f"\n  ✈  Pilot is ready — open http://localhost:{port} in your browser\n")
    app.run(host="127.0.0.1", port=port, debug=False)
