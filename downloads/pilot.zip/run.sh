#!/usr/bin/env bash
# ✈ Pilot — start the setup wizard
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$SCRIPT_DIR/.venv"
PYTHON="$VENV/bin/python"

# Create venv if missing
if [ ! -f "$PYTHON" ]; then
  echo "Setting up Pilot for the first time…"
  python3 -m venv "$VENV"
  "$VENV/bin/pip" install flask --quiet
  echo "Ready."
fi

echo ""
echo "  ✈  Starting Pilot at http://localhost:7700"
echo ""

# Try to open the browser
(sleep 1.5 && open "http://localhost:7700" 2>/dev/null || true) &

exec "$PYTHON" "$SCRIPT_DIR/pilot.py"
